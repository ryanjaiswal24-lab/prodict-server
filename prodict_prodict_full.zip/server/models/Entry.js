const mongoose = require('mongoose');
const entrySchema = new mongoose.Schema({
  user:{ type: mongoose.Schema.Types.ObjectId, ref:'User', required:true },
  date:{ type: Date, required:true },
  tasksCompleted:{ type:Number, default:0 },
  hoursWorked:{ type:Number, default:0 },
  sleepHours:{ type:Number, default:0 },
  mood:{ type:Number, default:3 },
  notes:{ type:String }
}, { timestamps:true });
module.exports = mongoose.model('Entry', entrySchema);

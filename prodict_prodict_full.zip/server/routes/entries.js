const express = require('express');
const Entry = require('../models/Entry');
const auth = require('../middleware/auth');
const router = express.Router();
router.post('/', auth, async (req,res)=>{ try{ const {date,tasksCompleted,hoursWorked,sleepHours,mood,notes}=req.body; const entry=new Entry({ user:req.user.id, date: date? new Date(date): new Date(), tasksCompleted, hoursWorked, sleepHours, mood, notes }); await entry.save(); res.json(entry);}catch(e){console.error(e);res.status(500).send('Server error');}});
router.get('/', auth, async (req,res)=>{ try{ const entries=await Entry.find({user:req.user.id}).sort({date:1}); res.json(entries);}catch(e){console.error(e);res.status(500).send('Server error');}});
router.put('/:id', auth, async (req,res)=>{ try{ const entry = await Entry.findById(req.params.id); if(!entry) return res.status(404).json({message:'Not found'}); if(entry.user.toString() !== req.user.id) return res.status(403).json({message:'Not allowed'}); Object.assign(entry, req.body); await entry.save(); res.json(entry);}catch(e){console.error(e);res.status(500).send('Server error');}});
router.delete('/:id', auth, async (req,res)=>{ try{ const entry = await Entry.findById(req.params.id); if(!entry) return res.status(404).json({message:'Not found'}); if(entry.user.toString() !== req.user.id) return res.status(403).json({message:'Not allowed'}); await entry.remove(); res.json({message:'Deleted'});}catch(e){console.error(e);res.status(500).send('Server error');}});
module.exports = router;

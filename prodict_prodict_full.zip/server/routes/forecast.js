const express = require('express');
const Entry = require('../models/Entry');
const auth = require('../middleware/auth');
const router = express.Router();
function productivityMetric(e){ return (e.tasksCompleted||0)*10 + (e.hoursWorked||0)*5 + (e.mood||3)*8 + (e.sleepHours||0)*2; }
function linearForecast(entries, days=7){
  if(!entries.length) return Array(days).fill(null);
  const base = new Date(entries[0].date);
  const xs = entries.map(e => (new Date(e.date)-base)/(1000*60*60*24));
  const ys = entries.map(e => productivityMetric(e));
  const n = xs.length;
  const xMean = xs.reduce((a,b)=>a+b,0)/n;
  const yMean = ys.reduce((a,b)=>a+b,0)/n;
  let num=0, den=0;
  for(let i=0;i<n;i++){ num+=(xs[i]-xMean)*(ys[i]-yMean); den+=(xs[i]-xMean)*(xs[i]-xMean); }
  const m = den===0?0:num/den;
  const b = yMean - m*xMean;
  const lastX = xs[xs.length-1];
  const out = [];
  for(let d=1; d<=days; d++){ const x= lastX + d; const y = m*x + b; out.push(Math.max(0, Math.round(y*100)/100)); }
  return out;
}
router.get('/next', auth, async (req,res)=>{ try{ const days = parseInt(req.query.days||'7',10); const entries = await Entry.find({user:req.user.id}).sort({date:1}); const forecast = linearForecast(entries, days); res.json({forecast, lastEntriesCount: entries.length}); }catch(e){console.error(e);res.status(500).send('Server error');}});
module.exports = router;

const express = require('express');
const bcrypt = require('bcryptjs');
const jwt = require('jsonwebtoken');
const User = require('../models/User');
const router = express.Router();
router.post('/register', async (req,res)=>{ try{ const {name,email,password}=req.body; if(!name||!email||!password) return res.status(400).json({message:'Missing fields'}); let u = await User.findOne({email}); if(u) return res.status(400).json({message:'User exists'}); const salt=await bcrypt.genSalt(10); const hashed=await bcrypt.hash(password,salt); u=new User({name,email,password:hashed}); await u.save(); const token=jwt.sign({id:u._id},process.env.JWT_SECRET,{expiresIn:'7d'}); res.json({token,user:{id:u._id,name:u.name,email:u.email}}); }catch(e){console.error(e);res.status(500).send('Server error');}});
router.post('/login', async (req,res)=>{ try{ const {email,password}=req.body; if(!email||!password) return res.status(400).json({message:'Missing fields'}); const u=await User.findOne({email}); if(!u) return res.status(400).json({message:'Invalid credentials'}); const ok=await bcrypt.compare(password,u.password); if(!ok) return res.status(400).json({message:'Invalid credentials'}); const token=jwt.sign({id:u._id},process.env.JWT_SECRET,{expiresIn:'7d'}); res.json({token,user:{id:u._id,name:u.name,email:u.email}}); }catch(e){console.error(e);res.status(500).send('Server error');}});
module.exports = router;

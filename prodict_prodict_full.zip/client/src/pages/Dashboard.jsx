import React, {useEffect,useState} from 'react'; import api from '../api'; import { Line } from 'react-chartjs-2'; import { Chart, LineElement, PointElement, CategoryScale, LinearScale, Tooltip, Legend } from 'chart.js'; Chart.register(LineElement, PointElement, CategoryScale, LinearScale, Tooltip, Legend);
function metric(e){ return (e.tasksCompleted||0)*10 + (e.hoursWorked||0)*5 + (e.mood||3)*8 + (e.sleepHours||0)*2; }
export default function Dashboard(){ const [entries,setEntries]=useState([]); const [forecast,setForecast]=useState([]);
  useEffect(()=>{ (async ()=>{ const r=await api.get('/entries'); setEntries(r.data); const f=await api.get('/forecast/next?days=14'); setForecast(f.data.forecast||[]); })(); },[]);
  const labels = entries.map(e=> new Date(e.date).toLocaleDateString());
  const dataPoints = entries.map(e=> metric(e));
  const forecastLabels = []; if(entries.length){ const last = new Date(entries[entries.length-1].date); for(let i=1;i<=forecast.length;i++){ const d=new Date(last); d.setDate(d.getDate()+i); forecastLabels.push(d.toLocaleDateString()); } }
  const data = { labels: labels.concat(forecastLabels), datasets: [ { label:'Historical', data: dataPoints.concat(Array(forecast.length).fill(null)), tension:0.3 }, { label:'Forecast', data: Array(dataPoints.length).fill(null).concat(forecast), tension:0.3, borderDash:[6,6] } ] };
  return (<div><div className='flex justify-between items-center mb-4'><h1 className='text-2xl'>Dashboard</h1><a href='/entries' className='px-4 py-2 rounded bg-indigo-600 text-white'>Entries</a></div><div className='bg-white p-4 rounded shadow'><Line data={data} /></div></div>); }
